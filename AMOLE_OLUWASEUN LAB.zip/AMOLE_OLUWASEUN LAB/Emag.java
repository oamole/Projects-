package subclass;
import subclass.Magazine;
public class Emag extends Magazine {
   private String URL;
   public Emag()
   {
      super();
   }

   public Emag(String title, String date, String author, int issue, int vol, String url)
   {
      super(title, date, author, issue, vol);
      this.URL = url;
   }

   public String getURL()
   {
      return this.URL;
   }

   public void setURL(String url)
   {
      this.URL = url;
   }

   public String toString()
   {
      return super.toString() + "URL: " + this.getURL() + "\n";
   }
}
