package subclass;
import superclass.Record;
public class Magazine extends Record {
   private int issueNum;
   private int volumeNum;
   public Magazine()
   {
      super();
   }

   public Magazine(String title, String date, String author, int issue, int vol)
   {
      super(title, date, author);
      this.issueNum  = issue;
      this.volumeNum = vol;
   }

   public int getIssueNo()
   {
      return this.issueNum;
   }

   public int getVolumeNo()
   {
      return this.volumeNum;
   }

   public void setIssueNO(int issue)
   {
      this.issueNum = issue;
   }

   public void setVolumeNo(int vol)
   {
      this.volumeNum = vol;
   }

   public String toString()
   {
      String str = "";

      str = str + super.toString();
      str = str + "Issue No.: " + this.getIssueNo() + "\n";
      str = str + "Volume No.: " + this.getVolumeNo() + "\n";
      return str;
   }
}
