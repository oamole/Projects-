package subclass;
import subclass.Magazine;
public class HardCopy extends Magazine {
   private String bookEdition;
   public HardCopy()
   {
      super();
   }

   public HardCopy(String title, String date, String author, int iNum, int vol, String edition)
   {
      super(title, date, author, iNum, vol);
      this.bookEdition = edition;
   }

   public String getEdition()
   {
      return this.bookEdition;
   }

   public void setEdition(String edition)
   {
      this.bookEdition = edition;
   }

   public String toString()
   {
      return super.toString() + "Edition: " + this.getEdition() + "\n";
   }
}
