package client;
import superclass.Record;
import subclass.*;
public class RecordClient{
	public static void main(String []args){
		HardCopyBook obj1 = new HardCopyBook();
		System.out.println("Printing obj1" + "\n" + obj1.toString());
		
		Emag obj2 = new Emag("Wireless Magazine", "10-01-2017", "Jack Kelso", 10, 12, "http://www.magazines.com/vol5/i2");
		System.out.println("Printing obj2" + "\n" + obj2.toString());
		
		Newspaper obj3 = new Newspaper("Washington Post", "10-05-2017", "Russell Goode", "Washington DC Edition");
		System.out.println("Printing obj3" + "\n" + obj3.toString());
		
	}

}