package superclass;
public class Record {
   private String title;
   private String author;
   private String date;
   private static int counter = 1000;
   private int ID;
   public Record()
   {
      this.author = "No Author";
      this.title  = "No Title";
      this.date   = "99-99-9999";
      this.ID     = this.counter;
      this.counter++;
   }

   public Record(String title, String date, String author)
   {
      this.title  = title;
      this.date   = date;
      this.author = author;
      this.ID     = this.counter;
      this.counter++;
   }

   public String getTitle()
   {
      return this.title;
   }

   public String getDate()
   {
      return this.date;
   }

   public String getAuthor()
   {
      return this.author;
   }

   public void setTitle(String title)
   {
      this.title = title;
   }

   public void setDate(String date)
   {
      this.date = date;
   }

   public void setAuthor(String author)
   {
      this.author = author;
   }

   public String toString()
   {
      String str = "";

      str = str + "ID: " + this.ID + "\n";
      str = str + "Title: " + this.getTitle() + "\n";
      str = str + "Date of publishing: " + this.getDate() + "\n";
      str = str + "Author(s): " + this.getAuthor() + "\n";
      return str;
   }
}
