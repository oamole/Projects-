package subclass;
import subclass.Books;
public class HardCopyBook extends Books {
   private int bookEdition;
   public HardCopyBook()
   {
      super();
   }

   public HardCopyBook(String title, String date, String author, int edition)
   {
      super(title, date, author);
      this.bookEdition = edition;
   }

   public int getEdition()
   {
      return this.bookEdition;
   }

   public void setEdition(int edition)
   {
      this.bookEdition = edition;
   }

   public String toString()
   {
      String ret;

      ret = super.toString() + "Edition: " + this.getEdition() + "\n";
      return ret;
   }
}
