package subclass;
import superclass.Record;
public class Newspaper extends Record {
   private String bookEdition;
   
   public Newspaper()
   {
      super();
   }

   public Newspaper(String title, String date, String author, String edition)
   {
      super(title, date, author);
      this.bookEdition = edition;
   }

   public String getEdition()
   {
      return this.bookEdition;
   }

   public void setEdition(String edition)
   {
      this.bookEdition = edition;
   }

   public String toString()
   {
      String str;

      str = super.toString() + "Edition: " + this.getEdition() + "\n";
      return str;
   }
}
