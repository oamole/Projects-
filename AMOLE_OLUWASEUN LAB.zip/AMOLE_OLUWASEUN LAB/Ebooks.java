package subclass;
import subclass.Books;
public class Ebooks extends Books {
   private String URL;
   public Ebooks()
   {
      super();
   }

   public Ebooks(String title, String date, String author, String url)
   {
      super(title, date, author);
      this.URL = url;
   }

   public String getURL()
   {
      return this.URL;
   }

   public void setURL(String url)
   {
      this.URL = url;
   }

   public String toString()
   {
      return super.toString() + "URL: " + this.getURL() + "\n";
   }
}
