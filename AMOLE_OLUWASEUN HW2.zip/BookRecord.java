package library.service.classes;
import library.service.classes.BookGenre;

public class BookRecord {
   private String bookTitle;
   private String[] authors;
   private BookGenre genre;
   private int bookID;
   private static int uniqueRecordId = 0;

   public BookRecord()
   {
      this.bookTitle = "No title";
      this.authors   = null;
      bookID         = BookRecord.uniqueRecordId++;
   }

   public BookRecord(String bookTitle, BookGenre genre, String[] authors)
   {
      this.bookTitle = bookTitle;
      this.authors   = authors;
      this.genre     = genre;
      bookID         = BookRecord.uniqueRecordId++;
   }

   public String getTitle()
   {
      return this.bookTitle;
   }

   public String[] getAuthor()
   {
      return this.authors;
   }

   public BookGenre getGenre()
   {
      return this.genre;
   }

   public int getBookID()
   {
      return this.bookID;
   }

   public void setTitle(String title)
   {
      this.bookTitle = title;
   }

   public void setAuthor(String[] author)
   {
      this.authors = author;
   }

   public void setGenre(BookGenre genre)
   {
      this.genre = genre;
   }

   public boolean equals(BookRecord userBook)
   {
      // equals function.
      // FIXME: Might have to change the comaparison for the enumeration.
      if ((this.getTitle().equals(userBook.getTitle())) &&
          (this.getAuthor().equals(userBook.getAuthor())) &&
          (this.genre == userBook.genre))
      {
         return true;
      }
      else
      {
         return false;
      }
   }

   public String toString()
   {
      // Maybe loop through genres(makes more sense.)
      //FIXME: Take all print statements out of one loop and only use for author
      // for (int i = 0; i < this.authors.length; i++) {
      //     System.out.println("==================================");
      //     System.out.println("Record No:" + BookRecord.uniqueRecordId);
      //     System.out.println("Title: " + this.getTitle());
      //     System.out.println("Genre: " + this.getGenre());
      //     System.out.println("Authors: " + this.authors[i]);
      //     // System.out.println("==================================");
      //
      // }
      String authorString = "";

      for (int i = 0; i < this.authors.length; i++)
      {
         authorString += authors[i] + " ";
      }
      return "Record No:" + this.bookID + "\n" + "Title:" + this.getTitle() + "\n" + "Genre: " + this.getGenre() + "\n" + "Authors:" + authorString + "\n";
   }
}
