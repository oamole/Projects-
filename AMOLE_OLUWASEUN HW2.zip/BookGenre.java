package library.service.classes;
public enum BookGenre
{
   GENRE_HISTORY, GENRE_SCIENCE, GENRE_ENGINEERING, GENRE_LITERATURE
};
