//import java.util.Scanner;
public class UseGeometric {
   public static void main(String [] args)
   {
      GeometricFigure [] shape = new GeometricFigure[10];

      shape[0] = new Square(6, 9);
      shape[1] = new Square(8, 7);
      shape[2] = new Square(19, 88);
      shape[3] = new Square(100, 25);
      shape[4] = new Square(2, 18);
      shape[5] = new Triangle(20, 5);
      shape[6] = new Triangle(14.5, 2);
      shape[7] = new Triangle(9, 8);
      shape[8] = new Triangle(19, 25);
      shape[9] = new Triangle(78, 12);
      for (int i = 0; i < 10; i++)
      {
         System.out.println("The area is : " + shape[i].area());
      }
   }
}
