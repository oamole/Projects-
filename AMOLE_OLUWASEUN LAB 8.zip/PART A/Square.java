public class Square extends GeometricFigure {
   public Square()
   {
      super();
   }

   public Square(double h, double w)
   {
      super(h, w);
   }

   public String toString()
   {
      String ret = super.toString();

      return ret;
   }

   public double area()
   {
      return super.getHeight() * super.getWidth();
   }
}
