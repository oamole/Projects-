public class Triangle extends GeometricFigure {
   public Triangle()
   {
      super();
   }

   public Triangle(double h, double w)
   {
      super(h, w);
   }

   public String toString()
   {
      String ret = super.toString();

      return ret;
   }

   public double area()
   {
      return super.getHeight() * 1 / 2 * super.getWidth();
   }
}
