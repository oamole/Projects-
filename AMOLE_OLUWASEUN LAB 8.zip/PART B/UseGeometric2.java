public class UseGeometric2{
   public static void main(String [] args)
   {
      GeometricFigure2 [] shape = new GeometricFigure2[10];

      shape[0] = new Square2(20, 50);
      shape[1] = new Square2(45, 2);
      shape[2] = new Square2(90, 8);
      shape[3] = new Square2(100, 25);
      shape[4] = new Square2(200, 12);
      shape[5] = new Triangle2(12, 5);
      shape[6] = new Triangle2(45, 2);
      shape[7] = new Triangle2(90, 8);
      shape[8] = new Triangle2(100, 25);
      shape[9] = new Triangle2(20, 12);
      for (int i = 0; i < 10; i++)
      {
         System.out.print("The area is : " + shape[i].area() + " The number of sides is: ");
       shape[i].displaySides();
         System.out.println();
      }
   }
}
