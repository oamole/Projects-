public class Triangle2 extends GeometricFigure2 implements SidedObject {
   public Triangle2()
   {
      super();
   }

   public Triangle2(double h, double w)
   {
      super(h, w);
   }

   public String toString()
   {
      String ret = super.toString();

      return ret;
   }

   public void displaySides()
   {
      System.out.println("3 Sides");
   }

   public double area()
   {
      return super.getHeight() * (double)(1.0 / 2.0) * super.getWidth();
   }
}
