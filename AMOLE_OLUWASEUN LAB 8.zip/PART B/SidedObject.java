interface SidedObject {
   public void displaySides();
}
