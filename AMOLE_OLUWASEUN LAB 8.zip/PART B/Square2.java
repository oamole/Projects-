public class Square2 extends GeometricFigure2 implements SidedObject {
   public Square2()
   {
      super();
   }

   public Square2(double h, double w)
   {
      super(h, w);
   }

   public String toString()
   {
      String ret = super.toString();

      return ret;
   }

   public void displaySides()
   {
      System.out.println("4 Sides");
   }

   public double area()
   {
      return super.getHeight() * (double)(1.0 / 2.0) * super.getWidth();
   }
}
