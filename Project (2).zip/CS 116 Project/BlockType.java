package cars.service;
public enum BlockType{
	BLOCK_NORMAL, BLOCK_TRAFFIC, BLOCK_INTERSECT
};
