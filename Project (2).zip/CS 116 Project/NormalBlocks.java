public class NormalBlocks extends Block{
    private String direction;
    private boolean entryBlock;
    private Boolean exitBlock;
    //getNext()

    public NormalBlocks(){
        super();
        direction = null;
    }   
    public NormalBlocks(int blockType, int positionNo){
        super(blockType,positionNo);
        if(positionNo == 1){
           this.setEntryBlock(true); 
        }else if (positionNo == ((span*2) + 2)){
            this.setExitBlock(true);
        }

    } 
    public boolean getEntryBlock(){
        return this.entryBlock;
    }
    public boolean getExitBlock(){
        return this.exitBlock;
    }
    public void setExitBlock(boolean exit){
        this.exitBlock = exit;
    }
    public void setEntryBlock(boolean entry){
        this.entryBlock = entry;
    }
    public void MoveForward(int tick, double turnRate){
		if(this.exitBlock && (this.getVehicle()!=null)){
			this.getVehicle().setExitTime(tick);
			System.out.println("Entry Time: " + this.getVehicle().getEntryTime());
			System.out.println("Exit Time: " + this.getVehicle().getExitTime());
			this.setVehicle(null);
		}
		else if((this.getNext().getVehicle() != null) && !(this.exitBlock)) {
			this.getNext().setVehicle(this.getVehicle());
			this.setVehicle(null);
		}
	}

    public void Process(int tick, double entryRate, double turnRate){
		if(this.getVehicle()!=null){
			this.MoveForward(tick, turnRate);
		}
		if(this.isEntryBlock() && (this.getVehicle()==null)){
			if(Math.random()<entryRate){
				System.out.println("Creating vehicle");
				Auto v = new Auto(tick);
				this.setVehicle(v);
			}
		}
	}
    
}