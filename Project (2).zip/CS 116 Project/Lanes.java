package cars.service;
import cars.service.BlockType;
import cars.service.Block;
import cars.service.NormalBlocks;
public class Lanes {
	Block [][] arrayLane;
	public Lanes(){
		arrayLane = null;
	}
	public Lanes(int span){
		arrayLane = new Block[4][(span*2)+2];
		for(int k = 0; k<4; k++){
			arrayLane[k] = this.setColumn(span, k);
		}
		for(int k = 0; k<4; k++){
			for(int i = 1; i<((span*2)+2); i++){
				arrayLane[k][i-1].setNext(span, arrayLane, k);
			}
		}
	}

	public Block[] setColumn(int span, int lane){
		Block[] column = new Block[(span*2)+2];
		Block aBlock = null;
		for(int i = 1; i<=((span*2)+2); i++){
			if((i<span)||(i>span+2)){
				aBlock = new Block(0, i);
			}
			if(i==span){
				aBlock = new Block(1, i);
			}
			if((i == span+1)||(i==span+2)){
				aBlock = new Block(2, i, span, lane);
			}

			column[i-1] = aBlock;
		}
		return column;
	}

}
