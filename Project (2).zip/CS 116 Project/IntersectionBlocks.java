package cars.service;
public class IntersectionBlocks{
    private Blocktype turnblock;
    IntersectionBlocks(int blockType, int positionNo, int span, Block[][] arrayLane, int lane){
	
		if(lane==0){
			if(positionNo==span+1){
				this.setTurnBlock(arrayLane[2][span+2]);
			}
			if(positionNo==span+2){
				this.setTurnBlock(arrayLane[3][span+1]);
			}
		}
		if(lane==1){
			if(positionNo==span+1){
				this.setTurnBlock(arrayLane[3][span+2]);
			}
			if(positionNo==span+2){
				this.setTurnBlock(arrayLane[2][span+1]);
			}
		}
		if(lane==2){
			if(positionNo==span+1){
				this.setTurnBlock(arrayLane[1][span+2]);
			}
			if(positionNo==span+2){
				this.setTurnBlock(arrayLane[0][span+1]);
			}
		}
		if(lane==3){
			if(positionNo==span+1){
				this.setTurnBlock(arrayLane[0][span+2]);
			}
			if(positionNo==span+2){
				this.setTurnBlock(arrayLane[1][span+1]);
			}
		}
	}

    public Block getTurnBlock() {
        return this.turnblock;
    }

    public void setTurnBlock(Block turnBlock) {
        this.turnBlock = turnBlock;
    }

    public void MoveForward(int tick, double turnRate) {
        if (Math.random() < turnRate) {
            this.turnBlock.setVehicle(this.getVehicle());
            this.setVehicle(null);
        } else {
            this.getNext().setVehicle(this.getVehicle());
            this.setVehicle(null);
        }
    }

    public void Process(int tick, double entryRate, double turnRate) {
        if ((this.getNext() == null) && (this.getVehicle() != null)) {
            this.MoveForward(tick, turnRate);
        }
    }
    //getTurn(done, turnrate)
    // provide information on all lanes and which lane
    // span information and lane block
    // getNext()
        // tells you what the next block is in the lane
    // check for the exit block first
}
