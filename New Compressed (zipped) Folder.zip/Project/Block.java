public abstract class Block{		
		private BlockType type; //0:normal,1:intersection,2:traffic-light
		private int BlockNo;
		private Auto vehicle = null; // object of the vehicle occupying the block
		private Block Next = this; // the next block on the lane
		private Block Prev; // previous block on the lane
		private boolean ProcessedFlag;//flag for indicate whether the block has been processed during current tick of the simulation
		Block(int blockType, int positionNo){
			this.setType(blockType);
			this.setBlockNo(positionNo);
		}
		public BlockType getType(){
			return this.type;
		}
		public void setType(int blockType){
			this.type = BlockType.values()[blockType]; // Calls the enum Blocktype and sets the blocks depending on the integer value
		}
		public boolean isProcessedFlag() {
			return ProcessedFlag;
		}
		public void setProcessedFlag(boolean processedFlag) {
			ProcessedFlag = processedFlag;
		}
		public int getBlockNo(){
			return this.BlockNo;
		}
		public void setBlockNo(int positionNo){
			this.BlockNo=positionNo;
		}
		public Auto getVehicle(){
			return this.vehicle;
		}
		public void setVehicle(Auto v){
			this.vehicle=v;
		}
		public Block getNext(){
			return this.Next;
		}
		public void setNext(int span, Block[][] laneArray, int k){
				this.Next = laneArray[k][this.getBlockNo()];
		}
		public abstract void MoveForward(int tick, double turnRate);//method to move the vehicle to the next place in the road
		public abstract void Process(int tick, double entryRate, double turnRate);
}