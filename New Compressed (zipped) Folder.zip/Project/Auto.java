
public class Auto{
    private int entryTime; // ticks
    private int exitTime;
    private static int cnt; // ticks
    private int ID;
    
    public Auto(){
        entryTime = 0;
        exitTime = 0;
        ID = cnt++;
    }
    public Auto(int entryTime){
        this.setEntryTime(entryTime);
        this.setExitTime(exitTime);
    }
    public int getEntryTime(){
        return this.entryTime;
    }
    public int getExitTime(){
        return this.exitTime;
    }
    public int getID(){
        return this.ID;
    }
    public void setEntryTime(int entryTime){
        this.entryTime = entryTime;
    }
    public void setExitTime(int exitTime){
        this.exitTime = exitTime;
    }
    public void setID(int cnt){
        this.ID = cnt++;
    }
}