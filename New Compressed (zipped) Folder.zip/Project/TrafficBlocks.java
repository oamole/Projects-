public class TrafficBlocks{
    String trafficLight;

   public TrafficBlocks(int blockType, int positionNo){
		super(blockType, positionNo);
	}

    public String getTrafficLight() {
        return trafficLight;
    }

    public void setTrafficLight(String trafficLight) {
        this.trafficLight = trafficLight;
    }

    public void MoveForward(int tick, double turnRate) {
        if (this.getNext().getVehicle() != null) {
            this.getNext().setVehicle(this.getVehicle());
            this.setVehicle(null);
        }
    }

    public void Process(int tick, double entryRate, double turnRate) {
        if (this.getTrafficLight().equals("green")) {
            if (this.getVehicle() != null) {
                this.MoveForward(tick, turnRate);
            }
        }
    }
    // getNext()
        // 
    // process()
        // Check if next block (turnblock)is empty
        // if next block is empty, move car to next block
}