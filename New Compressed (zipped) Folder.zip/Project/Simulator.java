import java.util.Scanner;

public class Simulator {
    // create lanes object
	public static void main(String[] args) {
		double entryRate;
		double turnRate;
		int durationOfGreen;
		int durOrange;
		int durRed;
		int simTime;
		int span;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a double value for an entry rate: ");
		entryRate = scan.nextDouble();
		
		System.out.println("Enter an turn rate: ");
		turnRate = scan.nextDouble();
		
		System.out.println("Enter a green duration in ticks: ");
		durationOfGreen = scan.nextInt();
		
		System.out.println("Enter an orange duration in ticks: ");
		durOrange = scan.nextInt();
		durRed = durationOfGreen + durOrange;
		
		System.out.println("Enter a simulation duration in ticks: ");
		simTime = scan.nextInt();
		
		System.out.println("Enter a span for the road: ");
		span = scan.nextInt();

		Lanes lanes = new Lanes(span);
        int traffic = 1;
        for(i = 0; i < simTime; i++){
			
			for(int j = 0; j <=4; i++){
				if(k<2){
					if (traffic <= durRed){
						lanes.laneArray[k][span].setTrafficLight("Red");
					}else if ((traffic>durRed) && (traffic<=durRed+durationOfGreen)){
						lanes.laneArray[k][span].setTrafficLight("green");
					}else{
						lanes.laneArray[k][span].setTrafficLight("oragne");
					}
				}
				else if(k >= 2){
					if (traffic <= durationOfGreen) {
						lanes.laneArray[k][span].setTrafficLight("green");
					} else if ((traffic > durationOfGreen) && (traffic <= durRed)) {
						lanes.laneArray[k][span].setTrafficLight("orange");
					} else {
						lanes.laneArray[k][span].setTrafficLight("red");
					}
				}

			}
			traffic++;
			if(traffic > (durRed *2)){
				traffic = 1;
			}

			for(int k = 0; k<4; k++){
				for(int j = ((span*2)+1); j >= 0; j++){
					lanes.laneArray[k][span].process();
				}
			}

            // upadate traffic block
            // process each lane(start from the exit block)
            // Check if I need to add new cars
                // check the entry block, if it is empty flip a coin and examine the turn rate 
        }
	}

}