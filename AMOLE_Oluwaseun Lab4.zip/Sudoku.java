package service.classes;
public class Sudoku{
  	int [][] score;
public Sudoku(){

  int [] [] score = new  int[9][9];
}
  public Sudoku(int [][] lines) {
		score = lines;
	}
  public int [] []getScore(){
		return score;
	}

  public void setScore(int [][] lines) {
    score = lines;
  }
  public String toString() {
    String f = "";
    int h = 0;
    for (int i=0;i<score.length;i++) {
      for (int j=0;j<score[i].length;j++) {
        h = score[i][j];
        f = f + h + " ";
      }
      f = f + "\n";
    }
    return f;
  }
  public boolean Game() {
    for(int i=0;i<3;i++) {
      for(int j=i+1;j<3;j++) {
        for(int g=0;g<3;g++) {
          if(score[g][i]==score[g][j]) {
            return true;
          }
        }
      }
    }
    for(int i=0;i<3;i++) {
      for(int j=i+1;j<3;j++) {
        for(int g=0;g<score.length;g++) {
          if(score[i][g]==score[j][g]) {
            return true;
          }
        }
      }
    }
    for(int i=0;i<score.length;i++) {
      for(int j=i+1;j<score.length;j++) {
        for(int g=0;g<score.length;g++) {
          if(score[g][i]==score[g][j]) {
            return true;
          }
        }
      }
    }
    for(int i=0;i<score.length;i++) {
      for(int j=i+1;j<score.length;j++) {
        for(int g=0;g<score.length;g++) {
          if(score[i][g]==score[j][g]) {
            return true;
          }
        }
      }
    }

  return false;
  }

}
