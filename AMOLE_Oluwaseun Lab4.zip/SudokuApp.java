import service.classes.Sudoku;

public class SudokuApp {
	public static void main(String [] args) {
    int[][] myLines = new int[9][9];
		Sudoku play = new Sudoku(myLines);
		for (int i=0;i<myLines.length;i++) {
			for (int j=0;j<myLines[i].length;j++) {
				int range = 9;
				int min = 1;
				int rndVal = (int)(Math.random()*(range)+min);
				myLines[i][j]= rndVal;
			}

		}
		//System.out.println(play.toString());
		if (play.Game()) {
			System.out.println(play.toString());
			System.out.println("Is Not a Valid Number\n");
		}else {
			System.out.println(play.toString());
		}
	}
  }
