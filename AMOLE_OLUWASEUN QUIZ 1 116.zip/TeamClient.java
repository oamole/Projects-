package MainClass;
import MainClass.OtherClasses.Conference;
import MainClass.OtherClasses.Team;
import java.util.*;
import java.io.*;
public class TeamClient{
  public static void main (String []args){
    try{

            Scanner scan = new Scanner(System.in);
            File TeamFile = new File("data.txt");
            Scanner TeamScan1 = new Scanner(TeamFile);
            Scanner TeamScan2 = new Scanner(TeamFile);
            int lineCount = 0;
            Team[] TeamArray = new Team[lineCount];
            while(TeamScan1.hasNextLine()){
                  lineCount++;
            }
            while(TeamScan2.hasNextLine()){
              String str = TeamScan2.nextLine();
              Team[] TeamData = str.split(":");
              String Name = TeamData[0];
            int Num_Wins = Integer.parseInt(TeamData[2]);
              int Num_Ties = Integer.parseInt(TeamData[3]);
              int Num_Losses = Integer.parseInt(TeamData[4]);
              String conf = TeamData[1];
              Team newTeam = new Team(Name,Num_Wins, Num_Losses, Num_Ties,Conference.valueOf(conf));

  }
}
catch(IOException ioe){
            System.out.println("Error has been detected, File cannot be found");
        }
        toString();
}
}
