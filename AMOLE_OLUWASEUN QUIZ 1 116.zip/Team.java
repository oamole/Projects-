package MainClass.OtherClasses;
import MainClass.OtherClasses.Conference;
public class Team {
   private static int UniqueID;
   private String TeamName;
   private int Wins;
   private int Losses;
   private int Ties;
   private int TotalGames;
   private Conference TeamConference;
   private int ID = 0;

public Team(){
  this.TeamName = "NO_NAME";
  this.Wins = 0;
  this.Losses = 0;
  this.Ties = 0;
  this.TotalGames = 0;
  this.TeamConference = Conference.UNKNOWN;
  this.ID = Team.UniqueID++;
  }
  public Team(String Name,int Num_Wins, int Num_Losses, int Num_Ties,Conference conf){
this.TeamName = Name;
    this.Wins = Num_Wins;
      this.Losses = Num_Losses;
      this.Ties = Num_Ties;
      this.TeamConference = conf;
      this.ID = Team.UniqueID++;
  }
  public String getTeamName(){
      return this.TeamName;
  }
  public int getWins(){
        return this.Wins;
    }
    public int getLosses(){
        return this.Losses;
    }
    public int getTies(){
        return this.Ties;
    }

    public Conference getTeamConference(){
        return this.TeamConference;
    }
    public int getID(){
        return this.UniqueID;
    }
    public void setWins(int W){
      this.Wins = W;
  }
  public void setLosses(int L){
      this.Losses = L;
  }
  public void setTies(int T){
      this.Ties = T;
  }
  public void setConference(Conference C){
      this.TeamConference = C;
  }
  public float CalculateStanding(){
    float standing = ((2 * this.getWins()) + this.getTies() + (-1 * this.getLosses()))/ (this.TotalGames);
      return standing;
  }
  public String toString(){
    String msg;
    msg = "Team Name is :" +getTeamName() + "The Team wins are :" +getWins() +"The Team Losses are :" +getLosses()+"The Team Ties are :"+getTies() +"The team Conference is :" +getTeamConference()+"The team Standing is :" +CalculateStanding();
    return msg;
  }
}
