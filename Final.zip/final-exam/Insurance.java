public abstract class Insurance{
    private int insuranceID;
    private String name;
    private int age;
    private String type;
    private int fee;
    public static int count = 0;

    public Insurance(String name, int age, String type, int fee){
        this.setName(name);
        this.setAge(age);
        this.setType(type);
        this.setCost(fee);
        this.insuranceID = count;
        count++;
    }
    public Insurance(String name, int age, String type){
        this.setName(name);
        this.setAge(age);
        this.setType(type);
        // this.setCost(fee);
        this.insuranceID = count;
        count++;
    }

    public int getPolicyID(){
        return this.insuranceID;
    }
    public String getName(){
        return this.name;
    }
    public int getAge(){
        return this.age;
    }
    public String getType(){
        return this.type;
    }
    public int getCost(){
        return this.fee;
    }

    public void setPoliciyID(int id){
        this.insuranceID = id;
    }
    public void setName(String policyHolderName){
        this.name = policyHolderName;
    }
    public void setAge(int policyHolderAge){
        this.age = policyHolderAge;
    }
    public void setType(String policyType){
        this.type = policyType;
    }
    public void setCost(int fee){
        this.fee = fee;
    }

    public int averageAge(){

    }
    public abstract void setCost();

}
