public class LifeInsurance extends Insurance{
    public LifeInsurance(String name, int age, String type, int fee){
        super(name, age, type, fee);
        // this.setCost(180);
    }

    public void setCost(){
        this.setCost(180);
}
}
