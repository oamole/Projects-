import java.util.*;

public class FindMax{
	public int getMax(int []nums){
		if (nums.length == 1) {
			return nums[0];
		}else{
			int num = getMax(Arrays.copyOf(nums, nums.length - 1));
			if (num > nums[nums.length - 1]) {
				return num;
			}
			else{
				return nums[nums.length - 1];
			}
		}
	}
	public static void main(String []args){
		int []a={113,2,5,23,98};
		FindMax max = new FindMax();
		System.out.println("Max no. is " + max.getMax(a));
	}

}
