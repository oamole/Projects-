import java.util.*;
public class InsuranceGroup {
   public static int count = 1000;
   private int uniqueID;
   Vector<String> insuranceData = new Vector<>();

   public InsuranceGroup()
   {
      this.uniqueID = count;
      count++;
   }

   public int getGroupID()
   {
      return this.uniqueID;
   }

   public void setGroupID(int id)
   {
      this.uniqueID = id;
   }

   // public int getAverage(){}

   public void AddPolicy(Insurance policyObject)
   {
       if ((insuranceData.length < 5) || (averageAge() < 45))
       {
          insuranceData.add(policyObject);
       }
   }

   public String toString()
   {
      String str = "";

      str += "Insurance Group ID: GR-" + this.getGroupID() + "\n";
      str += "No. of Policies" + "\n";
      str += "Total Monthly fee: " + this.getCost() + "\n";
      str += "Average age:" + this.averageAge() + "\n";
      return str;
   }
}
