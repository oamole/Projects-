

public abstract class Package implements ChargeConstants{
    private String fromAddress;
    private String toAddress;
    private float weight;
    private int packageID;
    private static int idCounter = 1000;

    public Package(String fromAdd, String toAdd, float weight){
        this.setFromAddress(fromAdd);
        this.setToAddress(toAdd);
        this.setWeight(weight);
        this.packageID = this.idCounter++;

    }

    // Accessors
    public int getPackageID(){
      return this.packageID;
    }
    public String getFromAddress(){
      return this.fromAddress;
    }
    public String getToAddress(){
      return this.toAddress;
    }
    public float getWeight(){
      return this.weight;
    }

    // Mutators
    public void setPackageID(int id){
        this.packageID = id;
    }
    public void setFromAddress(String fromAdd){
      this.fromAddress = fromAdd;
    }
    public void setToAddress(String toAdd){
      this.toAddress = toAdd;
    }

    public void setWeight(float weight){
      this.weight = weight;
    }

    // Helper Methods
    public float CalculateCharge(){
      float charge = baseCharge * this.getWeight();
      return charge;
    }

    public abstract String printReceipt();

  }
