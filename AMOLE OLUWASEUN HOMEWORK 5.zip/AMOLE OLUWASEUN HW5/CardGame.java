 package superclass;
 import subclass.Card;
import java.util.*;

public abstract class CardGame {
    public int deal = 0;
    public Vector<String> deck = new Vector<String>(52);

   public CardGame()
   {
     int counter = 0;
      for (int i = 0; i < Card.suit.length; i++)
      {
         for (int j = 0; j < Card.value.length; j++)
         {
            deck.add(counter, Card.suit[i] + " of " + Card.value[j]);
            counter++;
         }
      }
   }

   public void shuffle()
   {
      int deckNum = 52;

      for (int i = 0; i < deckNum; i++)
      {
         int    random = i + (int)(Math.random() * (deckNum - i));
         String str    = deck.elementAt(random);
         deck.set(random, deck.elementAt(i));
         deck.set(i, str);
      }
   }

   public abstract String displayDescription();
   public abstract void deal();
}
