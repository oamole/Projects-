package subclass;
import subclass.Poker;
import subclass.Bridge;
public class PlayCardGames{
    public static void main(String[] args) {
    Poker pok= new Poker();
		Bridge bri= new Bridge();

		System.out.println(pok.displayDescription());
		pok.deal();
		System.out.println(bri.displayDescription());
		bri.deal();
    }
}
