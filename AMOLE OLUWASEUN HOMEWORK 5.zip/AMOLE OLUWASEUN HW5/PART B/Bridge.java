 package subclass;
 import superclass.CardGame;

public class Bridge extends CardGame{
	public Bridge(){
		super.deal = 13;
        super.shuffle();
	}

    public String displayDescription(){
        return "Bridge game: Each player is given 13 cards";
    }

    public void deal(){
        for(int i = 0; i < deal; i++){
            System.out.println(deck.elementAt(i));
        }
    }
}
