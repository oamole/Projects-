 package subclass;

public class Card{
	private String name;
	public static String[] suit= {"Hearts", "Diamonds", "Spades", "Clubs"};
	public static String[] value= { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10",
	"Jack", "Queen", "King"};
}
