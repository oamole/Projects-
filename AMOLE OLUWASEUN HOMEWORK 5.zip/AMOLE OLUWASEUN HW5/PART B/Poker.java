 package subclass;
 import superclass.CardGame;

public class Poker extends CardGame{
	public Poker(){
		super.deal = 5;
		super.shuffle();
	}

    public String displayDescription(){
        return "Poker game: Each player is given 5 cards";
    }

    public void deal(){
        for(int i = 0; i < deal; i++){
            System.out.println(deck.elementAt(i));
        }
    }
}
