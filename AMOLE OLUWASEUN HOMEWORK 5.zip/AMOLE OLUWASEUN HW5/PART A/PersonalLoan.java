package subclass;
import superclass.Loan;

public class PersonalLoan extends Loan{
    public PersonalLoan(String lName, int amount, int term){
        super(lName, amount, term);
        super.setInterestRate(0.02);
    }
}
