package subclass;
import superclass.Loan;

public class BusinessLoan extends Loan{
    // private double businessRate;

    public BusinessLoan(String lName, int amount, int term){
        super(lName, amount, term);
        super.setInterestRate(0.01);
    }
}
