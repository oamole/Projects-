package subclass;
import superclass.Loan;
import subclass.BusinessLoan;
import subclass.PersonalLoan;
import java.util.*;

public class CreateLoans{
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double intRate = 1;
        Loan[] data = new Loan[5];
        int count = 0;
        System.out.println();
        System.out.println("Enter current prime interest rate");
        double option1 = scan.nextDouble();


        for (int i = 0; i < data.length; i++) {
            System.out.println("Loan Type (\"Personal\" or \"Business\")");
            String type = scan.next();
            System.out.println("Enter Last name:");
            String lname = scan.next();
            System.out.println("Enter Loan Amount: ");
            int lAmount = scan.nextInt();
            System.out.println("Enter Loan term: ");
            int loanTerm = scan.nextInt();
            System.out.println();

            if (type.equalsIgnoreCase("Personal")) {
                data[i] = new PersonalLoan(lname, lAmount, loanTerm);
                intRate += intRate * data[i].getLoanAmount();//Calculating int rate
            }
            else if (type.equalsIgnoreCase("Business")) {
                data[i] = new BusinessLoan(lname, lAmount, loanTerm);
                intRate += intRate * data[i].getLoanAmount();
            }
            else {
                System.out.println("You did not enter the correct type");
            }
        }
        // Print all Loan data
        for (int i = 0; i < data.length; i++) {
            System.out.println(data[i].toString());
        }
    }

}
