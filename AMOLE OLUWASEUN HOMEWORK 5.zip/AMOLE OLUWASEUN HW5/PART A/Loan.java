package superclass;
import constants.LoanConstants;

public abstract class Loan implements LoanConstants{
    private String lastName;
    private int loanAmount;
    private double interestRate;
    private int loanTerm;
    private static int uniqueID; //Loan number
    public int count = 1000;

    public Loan(){
        this.setLastName("No Last name");
        this.setLoanAmount(5000);
        this.setInterestRate(0.5);
        this.setLoanTerm(1);
        this.uniqueID = count;
        count++;
    }

    public Loan(String lName, int amount, int term){
        if (amount > 100000 || amount < 0) {
            System.exit(0);
        }
        else{
            this.setLastName(lName);
            this.setLoanAmount(amount);
            this.setInterestRate(0.0);
            this.setLoanTerm(term);
            this.uniqueID = this.count;
            this.count++;
        }

    }

    // accessors
    public String getLastName(){
        return this.lastName;
    }
    public int getLoanAmount(){
        return this.loanAmount;
    }
    public double getInterestRate(){
        return this.interestRate;
    }
    public int getLoanTerm(){
        if (this.loanTerm != SHORT_TERM && this.loanTerm != MID_TERM && this.loanTerm != LONG_TERM) {
            return SHORT_TERM;
        }
        else{
            return this.loanTerm;
        }
    }
    public int getLoanNumber(){
        return this.uniqueID;
    }

    // mutators
    public void setLastName(String lName){
        this.lastName = lName;
    }
    public void setLoanAmount(int amount){
        this.loanAmount = amount;
    }
    public void setInterestRate(double rate){
        this.interestRate = rate;
    }
    public void setLoanTerm(int term){
        this.loanTerm = term;
    }
    public void setLoanNumber(int uID){
        this.uniqueID = uID;
    }

    // toString & helper methods

    public String toString(){
        String str = "";
        str += "Loan number: " + this.getLoanNumber() + "\n";
        str += "Last name: " + this.getLastName() + "\n";
        str += "Amount: $" + this.getLoanAmount() + "\n";
        str += "Interest rate: " + this.getInterestRate() + "\n";
        str += "Term: " + this.getLoanTerm() + "\n";

        return str;
    }
}
