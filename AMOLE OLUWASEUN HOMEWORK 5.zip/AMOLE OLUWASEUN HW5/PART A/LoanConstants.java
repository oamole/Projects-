package constants;

public interface LoanConstants{
    final static int SHORT_TERM = 1;
    final static int MID_TERM = 3;
    final static int LONG_TERM = 5;
    final static String COMPANY_NAME = "";
    final static int MAX_LOAN = 100000;
}
