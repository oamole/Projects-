package subclass;
import superclass.Order;

public class Repeated extends Order{
    private int period;
    private String endDate;

    public Repeated(){
        super();
    }
    public Repeated(String customer, String product, String date, int amount,int per, String enddate){
        super(customer, product, date, amount);
        this.setPeriod(per);
        this.setEndDate(enddate);
    }

    // accessors
    public int getPeriod(){
        return this.period;
    }
    public String getEndDate(){
        return this.endDate;
    }

    // mutators
    public void setPeriod(int per){
        this.period = per;
    }
    public void setEndDate(String enddate){
        this.endDate = enddate;
    }

    public String toString(){
        String str;
        str = super.toString();
        str = str + "Period: " + this.getPeriod() + "\n";
        str = str + "End Date: " + this.getEndDate() + "\n";

        return str;
  }

}
