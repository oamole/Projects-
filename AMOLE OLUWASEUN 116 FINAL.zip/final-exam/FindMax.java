import java.util.*;

public class FindMax{
	public int getMax(int []numbers){
		if (numbers.length == 1) {
			return numbers[0];
		}else{
			int n = getMax(Arrays.copyOf(numbers, numbers.length - 1));
			if (n > numbers[numbers.length - 1]) {
				return n;
			}
			else{
				return numbers[numbers.length - 1];
			}
		}
	}
	public static void main(String []args){
		int []a={890,35362,272818,9832,28272};
		FindMax max = new FindMax();
		System.out.println("The Maximum Number in the array is: " + max.getMax(a));
	}

}
