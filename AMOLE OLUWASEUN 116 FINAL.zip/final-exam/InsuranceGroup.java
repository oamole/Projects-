package Health;
import Health.HealthInsurance;
import Health.Insurance;
import Health.LifeInsurance;
import java.util.*;
public abstract class InsuranceGroup extends Insurance {
   public static int count = 1000;
   private int uniqueID;
   Vector<Insurance> insuranceData = new Vector<>();

   public InsuranceGroup()
   {

      this.uniqueID = count;
      count++;
   }

   public int getGroupID()
   {
      return this.uniqueID;
   }

   public void setGroupID(int id)
   {
      this.uniqueID = id;
   }

   public int averageAge(){
    int Average;
    Average = getAge()/insuranceData.size();
    return Average;
   }



   public void AddPolicy(Insurance policyObject)
   {
       if ((insuranceData.size() < 5) || (this.averageAge() < 45))
       {
          insuranceData.add(policyObject);
       }
   }

   public String toString()
   {
      String str = "";

      str += "Insurance Group ID: GR-" + this.getGroupID() + "\n";
      str += "No. of Policies:" + "\n";
      str += "Total Monthly fee: " + this.getCost() + "\n";
      str += "Average age:" + this.averageAge() + "\n";
      return str;
   }
}
