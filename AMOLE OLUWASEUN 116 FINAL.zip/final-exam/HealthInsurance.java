package Health;
public class HealthInsurance extends Insurance{
    public HealthInsurance(String name, int age, String type, int fee){
        super(name, age, type, fee);
        // this.setCost(180);
    }

    public void setCost(){
        this.setCost(40);
    }
}
