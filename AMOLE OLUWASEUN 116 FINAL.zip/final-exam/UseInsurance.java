package Health;
import Health.HealthInsurance;
import Health.Insurance;
import Health.InsuranceGroup;
import Health.LifeInsurance;
import java.util.*;
import java.io.File;
import java.io.IOException;
public class UseInsurance {
	public static void main(String []args){


		Scanner scan;
		String str;
		HealthInsurance health;
		LifeInsurance life;
		InsuranceGroup group;
		Vector<InsuranceGroup> test = new Vector<InsuranceGroup>();
		try {
			File myFile=new File("insurance.txt");
            scan=new Scanner(myFile);//each line has the format

			while(scan.hasNextLine()){
				str=scan.nextLine();
				String []tok=str.split(";");
				String name=tok[0];//name of the policy holder
				int age = Integer.parseInt(tok[1]);//age of the policy holder
				String type = tok[2];//type of the insurance values are "Health" or "Life"
				int fee = Integer.parseInt(tok[3]);
				if(type.compareTo("Health")==0){
					//this is a Health insurance policy
					health = new HealthInsurance(name, age, type,fee);
				 group.AddPolicy(health);
				}
				else{
					//this is a Life insurance policy
					life = new LifeInsurance(name, age, type,fee);
					group.AddPolicy(life);
					}


	} scan.close();
        }catch(IOException ioe){
			System.out.println("The file can not be read");
		}

	}
}
