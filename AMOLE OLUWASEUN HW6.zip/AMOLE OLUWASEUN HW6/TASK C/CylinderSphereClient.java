public class CylinderSphereClient{
    public static void main(String[] args) {
        Cylinder cylinder1 = new Cylinder(3.0, 5.0f);
        Sphere sphere1 = new Sphere(5.0);

        System.out.println("Cylinder ");
        System.out.println(cylinder1.toString());
        System.out.println("Sphere ");
        System.out.println(sphere1.toString() + "\n");

        CircleVolume cirCylinder = new Cylinder(3.7, 5.0f);
        CircleVolume circSphere = new Sphere(4.5);


        CircleVolume[] cVolArray= new CircleVolume[4];
        cVolArray[0]=new Cylinder(2.5,3.5f);
        cVolArray[1]=new Cylinder(4,3.0f);
        cVolArray[2]=new Sphere(4.5);
        cVolArray[3]=new Sphere(2.0);

        System.out.println("Array Items:");
        for (int i = 0; i < cVolArray.length; i++) {
            System.out.println(cVolArray[i].toString() + "\n");
        }
    }
}
