public abstract class CircleVolume{
    private double radius;

    public CircleVolume(){
      this.setRadius(0.0);
    }
    public CircleVolume(double r){
      this.setRadius(r);
    }
    public CircleVolume(CircleVolume cVol){
     this.setRadius(cVol.getRadius());
    }

    public void setRadius(double r){
        this.radius = r;
    }
    public double getRadius(){
        return this.radius;
    }
    public double getArea(){
        return Math.PI * Math.pow(this.radius, 2);
    }
    public double getCircumfrence(){
        return Math.PI * (this.radius * 2);
    }
    public String toString(){
        String str = "Area: " + this.getArea() + "\n";
        str += "Circumference: " + this.getCircumfrence() + "\n";
        return str;
    }

    public abstract double getVolume();

}
