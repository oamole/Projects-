public class Cylinder extends CircleVolume {
   private float height;

   public Cylinder()
   {
      super(0);
      this.height = 0.0f;
   }

   public Cylinder(double r, float h)
   {
      super(r);
      this.height = h;
   }

   public Cylinder(CircleVolume cVol, float h)
   {
      super(cVol.getRadius());
      this.height = h;
   }

   public void setHeight(float h)
   {
      this.height = h;
   }

   public float getHeight()
   {
      return this.height;
   }

   public double getVolume()
   {
      return this.getArea() * this.height;
   }

   public String toString()
   {
      String str = super.toString();
      str += "Height: " + this.getHeight() + "\n";
      str += "Volume: " + this.getVolume() + "\n";
      return str;
   }
}
