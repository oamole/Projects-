public class Sphere extends CircleVolume{
    public Sphere(){
        super(1.0);
    }
    public Sphere(double r){
        super(r);
    }
    public Sphere(CircleVolume cVol){
        super(cVol.getRadius());
    }

    public double getVolume(){
        return (double)(4/3) * Math.PI * Math.pow(super.getRadius(), 3);
    }
    public String toString(){
        String str = super.toString();
        str += "Volume: " + this.getVolume();
        return str;
    }
}
