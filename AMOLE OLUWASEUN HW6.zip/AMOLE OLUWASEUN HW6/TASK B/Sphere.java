public class Sphere extends Circle{
    public Sphere(){
        super(3.0);
    }
    public Sphere(double r){
        super(r);
    }
    public Sphere(Circle c){
        super(c.getRadius());
    }

    public double getVolume(){
        double vol = (double)(4/3) * Math.PI * Math.pow(super.getRadius(), 3);
        return vol;
    }
    public String toString(){
        String str = super.toString();
        str += "Volume: " + this.getVolume();
        return str;
    }
}
