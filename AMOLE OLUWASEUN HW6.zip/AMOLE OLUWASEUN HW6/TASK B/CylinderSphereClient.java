public class CylinderSphereClient{
    public static void main(String[] args) {
        Cylinder cylinder1 = new Cylinder(28.0, 35.0f);
        Sphere sphere1 = new Sphere(6.0);
        Circle circle1 = new Circle(12.0);
        Circle circleCylinder = new Cylinder(5.0, 5.0f);
        Circle circleSphere = new Sphere(7.5);


        System.out.println("Cylinder One");
        System.out.println(cylinder1.toString() + "\n");
        System.out.println("Sphere One");
        System.out.println(sphere1.toString() + "\n");
        System.out.println("Circle / Cylinder: ");
        System.out.println(circleCylinder.toString() + "\n");
        System.out.println("Circle / Sphere");
        System.out.println(circleSphere.toString() + "\n");

        Circle[] circArray = new Circle[3];
        circArray[0] = new Circle(2.3);
        circArray[1] = new Cylinder(5.0, 3.0f);
        circArray[2] = new Sphere(6.0);

        System.out.println("Circle Array:");
        for (int i = 0; i < circArray.length; i++) {
            System.out.println(circArray[i].toString());
        }

    }
}
