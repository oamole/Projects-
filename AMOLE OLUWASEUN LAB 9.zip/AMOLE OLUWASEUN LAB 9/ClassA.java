package superclass;

public abstract class ClassA{
    public int a;
    private double aa;

    // default constructor
    public ClassA(){
        this.setA(0);
        this.setAA(0.0);
        System.out.println("Default constructor of Class A");
    }
    // non-default constructor
    public ClassA(int a, double aa){
        this.setA(a);
        this.setAA(a);
    }

    // accessors
    public int getA(){ //Might not even need an accessor b/c it is 'public'
        return this.a;
    }
    public double getAA(){
        return this.aa;
    }

    // mutators
    public void setA(int a){
        this.a = a;
    }
    public void setAA(double aa){
        this.aa = aa;
    }

    public String toString(){
        return "Class A is executing now";
    }

    public int m2(char a){
        int x = (int)a;
        System.out.println("m2 is executing now");
        return x;
    }
    public int m2(int x1){
        int y = 10 + x1;
        System.out.println("Second version of m2 in A is executing now");
        return y;
    }
    public void m3(){
        System.out.println("m3 of A is executing now");
    }
    public abstract int m1();
}
