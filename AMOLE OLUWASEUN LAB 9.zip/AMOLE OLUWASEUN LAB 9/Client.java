package client;
import superclass.ClassA;
import subclass.ClassB;
import subclass.ClassC;
import subclass.ClassD;

public class Client{
    public static void main(String[] args) {
        System.out.println("FIRST OUTPUT" + "\n");
        ClassA objA;
        ClassB objB = new ClassB();
        ClassC objC = new ClassC();


        objA = objB;
        objA.toString();
        objA.m1();
        System.out.println();

        System.out.println("FIRST OUTPUT" + "\n");
        ClassD objD= new ClassD();
        objA = objD;
        objA.toString();
        objA.m3();
        System.out.println();

    	System.out.println("THIRD OUTPUT" + "\n");
    	objD.m2('e');
    	objA.m2('c');
    }
}
