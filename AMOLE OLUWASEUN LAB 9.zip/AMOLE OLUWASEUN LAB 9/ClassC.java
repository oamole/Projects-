package subclass;
import superclass.ClassA;
import subclass.ClassB;

public class ClassC extends ClassA{
    public double c;

    public ClassC(){
        super();
        this.setC(0.0);
        System.out.println("Default constructor of Class C");
    }
    public ClassC(int a, double aa, double c){
        super(a, aa);
        this.setC(c);
    }

    public double getC(){
        return this.c;
    }
    public void setC(double c) {
        this.c = c;
    }

    public String toString(){
        String str = "";
        str += super.toString();
        return str;
    }
    public int m1(){
        int i2 = this.getA() + (int)(this.getC()/2);
        System.out.println("m1 implementation of C is executing now");
        return i2;
    }
}
