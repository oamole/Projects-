package subclass;
import superclass.ClassA;

public class ClassB extends ClassA{
    public String s;

    public ClassB(){
        super();
        this.setS("test");
        System.out.println("Default constructor of Class B");
    }
    public ClassB(int a, double aa, String s){
        super(a, aa);
        this.setS(s);
    }

    public String getS(){
        return this.s;
    }
    public void setS(String s){
        this.s = s;
    }
    public String toString(){
        return super.toString();
    }

    public int m1(){
        int i1 = 5*this.getA() + (int)this.getAA();
        System.out.println("m1 implementation of B is executing now");
        return i1;
    }
}
